package hw214_2;

public class PolyDbl implements Ring, Modulo, Ordered {
    private double[] coef;
    public PolyDbl(double[] coef) {
    	int n = coef.length;
    	while(n >= 2 && coef[n-1] == (double)0){
    		n--;
    	}
    	this.coef = new double[n];
    	for(int i = 0; i < n; i++)
    		this.coef[i] = coef[i];
    	//TODO: implement this constructor 
    }
    //TODO: implement the rest
    public String toString() {
        String str = "";
        for(int i = coef.length - 1; i > 0; i--)
            str = str + coef[i] + "x^" + i + " + ";
        str = str + coef[0];
        return str;
    }
    public double[] getCoef(){
    	return coef;
    }
    public Ring add(Ring a) {
    	PolyDbl that = (PolyDbl)a;
    	double[] temp, smaller;
    	if(this.coef.length > that.getCoef().length) {
    		temp = this.coef;
    		smaller = that.getCoef().clone();
    	}
    	else {
    		temp = that.getCoef().clone();
    		smaller = this.coef;
    	}
    	for(int i = 0; i < smaller.length; i++) {
   			temp[i] = temp[i] + smaller[i];
    	}
    	return new PolyDbl(temp);
    }
    public Ring addIdentity() {
    	return new PolyDbl(new double[] {0});
    }
    public Ring addInverse() {
    	return this.mul(new PolyDbl(new double[] {-1})); // 자신에 that값을 더하면 0이 나오는 
    }
    public Ring mul(Ring a) {
    	PolyDbl that = (PolyDbl)a;
    	 double[] c = new double[(this.coef.length + that.coef.length) - 1];
         for(int i = 0; i < this.coef.length; i++)
             for(int j = 0; j < that.coef.length; j++)
                 c[i+j] += this.coef[i] * that.coef[j];
         return new PolyDbl(c);
    }
    public Ring mod(Ring a) {   //remainder
    	PolyDbl that = (PolyDbl)a;
    	return this.division(that)[1];
    }
    public Ring quo(Ring a) {   //quotient
    	PolyDbl that = (PolyDbl)a;
    	return this.division(that)[0];
    	
    }
    public PolyDbl[] division(PolyDbl that) {
        int dd = that.coef.length - 1;  //degree of divisor
        double[] q = new double[this.coef.length - that.coef.length + 1]; //quotient
        double[] r = new double[this.coef.length];  //remainder
        for(int i = 0; i < this.coef.length; i++)
            r[i] = this.coef[i];
        for(int qi = q.length-1; qi >= 0; qi--) {
            q[qi] = r[qi + dd] / that.coef[dd];
            for(int i = 0; i <= dd; i++)
                r[qi+i] = r[qi+i] - q[qi] * that.coef[i];
        }
        return new PolyDbl[] {new PolyDbl(q), new PolyDbl(r)};
    }
    public boolean ge(Ordered a) {   //greater than or equal to
    	PolyDbl that = (PolyDbl)a;
    	if(this.coef.length > that.getCoef().length) {
    		return true;
    	}
    	else if(this.coef.length == that.getCoef().length){
    		for(int i = this.coef.length-1 ; i >= 0; i--) {
    			if(this.coef[i] > that.getCoef()[i]) {
    				return true;
    			}
    			else if(this.coef[i] < that.getCoef()[i]) {
    				return false;
    			} 
    		}
    		return true;

    	}
    	return false;


    }
    
}
