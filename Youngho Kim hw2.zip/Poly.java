package hw214_2;

@SuppressWarnings("unchecked")
public class Poly<F extends Field> implements Ring, Modulo, Ordered {
    private F[] coef;
    public Poly(F[] coef) {
        int n = coef.length;
        while(n >= 2 && Comp.eq(coef[n-1], coef[0].addIdentity()))
            n--;
        this.coef = (F[])new Field[n];
        for(int i = 0; i < n; i++)
            this.coef[i] = coef[i];
            
    }    
    //TODO: implement the rest
    public String toString() {
        String str = "";
        for(int i = coef.length - 1; i > 0; i--)
            str = str + coef[i] + "x^" + i + " + ";
        str = str + coef[0];
        return str;
    }
    public F[] getCoef(){
    	return coef;
    }
    public Ring add(Ring a) {
    	Poly that = (Poly)a;
    	F[] temp;
    	if(this.coef.length > that.getCoef().length) {
    		temp = this.coef;
    		for(int i = 0; i < that.getCoef().length; i++) {
       			temp[i] = (F)temp[i].add(that.getCoef()[i]);//템프i에 들어있는 어레이를 f로 변
        	}
    	}
    	else {
    		temp = (F[])that.getCoef().clone();//템프전체를 f로변
    		for(int i = 0; i < this.coef.length; i++) {
       			temp[i] = (F)temp[i].add(this.coef[i]);//템프i에 들어있는 어레이를 f로 변
        	}
    	}
    	
    	return new Poly(temp);
    }
    public Ring addIdentity() {
    	return new Poly((F[])new Field[] {(F)coef[0].addIdentity()});
    }
    public Ring addInverse() {
    	F[] temp = this.coef.clone();
    	for(int i = 0; i < this.coef.length; i++) {
    		temp[i] = (F)this.coef[i].addInverse();
    	}
    	return new Poly(temp); // 자신에 that값을 더하면 0이 나오는 
    }
    public Ring mul(Ring a) {
    	Poly that = (Poly)a;
    	 F[] c = (F[]) new Field[(this.coef.length + that.coef.length) - 1];
         for(int i = 0; i < this.coef.length; i++) {
             for(int j = 0; j < that.coef.length; j++) {
            	 if(c[i+j] != null) {
                 	c[i+j] = (F)c[i+j].add(this.coef[i].mul(that.coef[j]));
            	 }
            	 else {
            		 c[i+j] = (F)this.coef[i].mul(that.coef[j]);
            	 }
             }
         }
         return new Poly(c);
    }
    public Ring mod(Ring a) {   //remainder
    	Poly that = (Poly)a;
    	return this.division(that)[1];
    }
    public Ring quo(Ring a) {   //quotient
    	Poly that = (Poly)a;
    	return this.division(that)[0];
    	
    }
    public Poly[] division(Poly that) {
        int dd = that.coef.length - 1;  //degree of divisor
        F[] q = (F[])new Field[this.coef.length - that.coef.length + 1]; //quotient F는 필드 하위, Generic 은new가 불가능 해서 필드로 변환해줘야
        F[] r = (F[])new Field[this.coef.length];  //remainder
        for(int i = 0; i < this.coef.length; i++)
            r[i] = this.coef[i];
        for(int qi = q.length-1; qi >= 0; qi--) {
            q[qi] = (F)r[qi + dd].mul(that.coef[dd].mulInverse());
            for(int i = 0; i <= dd; i++)
                r[qi+i] = (F)r[qi+i].add((q[qi].mul(that.coef[i]).addInverse())); //add inverse 이용해서 - 하
        }
        return new Poly[] {new Poly(q), new Poly(r)};
    }
    public boolean ge(Ordered a) {   //greater than or equal to
    	Poly that = (Poly)a;
    	if(this.coef.length > that.getCoef().length) {
    		return true;
    	}
    	else if(this.coef.length == that.getCoef().length){
    		for(int i = this.coef.length-1 ; i >= 0; i--) {
    			if(Comp.gt(this.coef[i], that.getCoef()[i])) {
    				return true;
    			}
    			else if(Comp.lt(this.coef[i], that.getCoef()[i])) {
    				return false;
    			} 
    		}
    		return true;

    	}
    	return false;


    }
}
